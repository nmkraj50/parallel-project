create database Training_13Aug19_Pune
go
USE Training_13Aug19_Pune
GO
create schema Anamika_46004682
go
CREATE TABLE [Anamika_46004682].[Customer]
(
CustomerID INT PRIMARY KEY IDENTITY(1,1),
CustomerName VARCHAR(50) NOT NULL,
City VARCHAR(30) NOT NULL,
Age INT NOT NULL,
Phone BIGINT NOT NULL,
Pincode INT NOT NULL
)
go
CREATE PROCEDURE [Anamika_46004682].[InsertCustomer]
@CustomerName VARCHAR(50),
@City VARCHAR(30),
@Age INT,
@Phone BIGINT,
@Pincode INT
AS
BEGIN
	INSERT INTO [Anamika_46004682].[Customer] VALUES (@CustomerName,@City,@Age,@Phone,@Pincode)
END
go

CREATE PROCEDURE [Anamika_46004682].[SelectAllCustomers]
AS
BEGIN
	SELECT * FROM [Anamika_46004682].[Customer]
END
go
CREATE PROCEDURE [Anamika_46004682].[SelectCustomerByID]
@CustomerID INT
AS
BEGIN
	SELECT * FROM [Anamika_46004682].[Customer] WHERE CustomerID=@CustomerID
END
go
CREATE PROCEDURE [Anamika_46004682].[UpdateCustomer]
@CustomerID INT,
@CustomerName VARCHAR(50),
@City VARCHAR(30),
@Age INT,
@Phone BIGINT,
@Pincode INT
AS
BEGIN
	UPDATE [Anamika_46004682].[Customer] SET CustomerName=@CustomerName, City=@City, Age=@Age, Phone=@Phone, Pincode=@Pincode WHERE CustomerID=@CustomerID
END
go
CREATE PROCEDURE [Anamika_46004682].[DeleteCustomer]
@CustomerID INT
AS
BEGIN
	DELETE FROM [Anamika_46004682].[Customer] WHERE CustomerID=@CustomerID
END
go
CREATE PROCEDURE [Anamika_46004682].[SelectCustomerByName]
@CustomerName VARCHAR(50)
AS
BEGIN
	SELECT * FROM [Anamika_46004682].[Customer] WHERE CustomerName=@CustomerName
END