﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS.DataAccessLayer;
using CMS.Entities;
using CMS.Exceptions;
using System.Text.RegularExpressions;

namespace CMS.BusinessLogicLayer
{
    public class CustomerBLL
    {
         private static bool ValidationCustomerBLL(Customer customerDetails) 
         {
            bool customerValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                if (string.IsNullOrEmpty(customerDetails.CustomerName))
                {
                    customerValidated = false;
                    message.Append(Environment.NewLine + "Customer Name cannot be Null or Empty");
                }
                else if (!Regex.IsMatch(customerDetails.CustomerName, @"^[A-Z][A-Za-z\s]+$"))
                {
                    customerValidated = false;
                    message.Append(Environment.NewLine + "Customer Name must start with a Capital Letter and must only have letters");
                }               
                if (string.IsNullOrEmpty(customerDetails.City))
                {
                    customerValidated = false;
                    message.Append(Environment.NewLine + "City cannot be Null or Empty");
                }
                if (customerDetails.Age < 1)
                {
                    customerValidated = false;
                    message.Append(Environment.NewLine + "Customer Age must be greater than 0");
                }

                if (customerDetails.Phone < 6000000000 && customerDetails.Phone > 9999999999)
                {
                    customerValidated = false;
                    message.Append(Environment.NewLine + "Phone number must have 10 digits and must start with 6/7/8/9");
                }

                if (customerDetails.Pincode < 100000 && customerDetails.Phone > 999999)
                {
                    customerValidated = false;
                    message.Append(Environment.NewLine + "Pincode must have 6 digits and must not start with 0");
                }

                if (customerValidated == false)
                {
                    throw new CustomerException(message.ToString());
                }

            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerValidated;
        }

        //Wrapper method to Add a new Customer

        public static bool AddCustomerBLL(Customer newCustomer)
        {
            bool customerAdded = false;

            try
            {
                if (ValidationCustomerBLL(newCustomer))
                {
                    customerAdded = CustomerDAL.AddCusotmerDAL(newCustomer);
                }
                else
                {
                    throw new CustomerException(Environment.NewLine + "Invalid Customer Details!");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerAdded;
        }

        //Wrapper method to show Customer Summary

        public static List<Customer> ListAllCustomersBLL()
        {
            List<Customer> customerList = new List<Customer>();

            try
            {
                customerList = CustomerDAL.ListAllCustomersDAL();
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerList;
        }

        //Wrapper method to Remove a Customer's Details

        public static bool RemoveCustomerBLL(int deleteID)
        {
            bool customerDeleted = false;

            try
            {
                customerDeleted = CustomerDAL.RemoveCustomerDAL(deleteID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerDeleted;
        }

        //Wrapper method to Modify a Customer's Details

        public static bool ModifyCustomerBLL(Customer modifiedCustomer)
        {
            bool customerModified = false;

            try
            {
                if (ValidationCustomerBLL(modifiedCustomer))
                {
                    customerModified = CustomerDAL.ModifyCustomerDAL(modifiedCustomer);
                }
                else
                {
                    throw new CustomerException(Environment.NewLine + "Invalid Customer Details!");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerModified;
        }

        //Wrapper method to Search By CustomerID

        public static Customer SearchCustomerByIdBLL(int searchID)
        {
            Customer searchedCustomer = null;

            try
            {
                searchedCustomer = CustomerDAL.SearchCustomerByIdDAL(searchID);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return searchedCustomer;
        }

        //Wrapper method to Search By Customer Name

        public static List<Customer> SearchCustomerByNameBLL(string searchName)
        {
            List<Customer> searchedCustomer = null;

            try
            {
                searchedCustomer = CustomerDAL.SearchCustomerByNameDAL(searchName);
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return searchedCustomer;
        }
    }
}
