﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.BusinessLogicLayer;
using CMS.Entities;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    public partial class CreateCustomer : Window
    {
        public CreateCustomer()
        {
            InitializeComponent();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer newCustomer = new Customer();
                newCustomer.CustomerName = txtName.Text;
                newCustomer.City = txtCity.Text;
                newCustomer.Age = Convert.ToInt32(txtAge.Text);
                newCustomer.Phone = Convert.ToInt64(txtPhone.Text);
                newCustomer.Pincode = Convert.ToInt32(txtPincode.Text);
                bool employeeAdded = CustomerBLL.AddCustomerBLL(newCustomer);
                if (employeeAdded)
                    MessageBox.Show("Customer Added");
                else
                    MessageBox.Show("Customer Not Added");
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.Close();
        }

    }
}
